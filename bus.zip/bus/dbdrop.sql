

use dbdrop.sql;

delete from reserve;
drop table reserve;

delete from customer;
drop table customer;

delete from bus;
drop table bus;

drop table seat;

delete from route;
drop table route;

delete from admin;
drop table admin;

drop database ticket;


