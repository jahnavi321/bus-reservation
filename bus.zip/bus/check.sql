

--commands to check db creation---

show tables;

show triggers;

select * from route;

select * from bus;


-- validates seat record insert trigger created on bus -------
select * from seat;


---check available tickets after successful reservation, validates update trigger created on reserve---

select * from bus where id=<use the id for which ticket is booked>;


