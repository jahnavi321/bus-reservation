<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
$link = mysqli_connect('localhost', 'root', 'rushi123','ticket');
if (!$link)
{
   die('Connect Error (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
}
	
$id=$_GET['id'];
$date=$_GET['doj'];

$vardate = str_replace('/', '-', $date);

$date = date('Y-m-d', strtotime($vardate));


$result = mysqli_query($link,"SELECT * FROM bus WHERE id='$id'");

$row = mysqli_fetch_array($result);
	
$seatnum=$row['capacity'];
	
?>
<strong>Bus Seat Layout </strong><br>
<?php
echo '<input type="button" style="background-color:red; border:none; width:23px; padding:2px; margin:2px;disabled=true;value="" />';
echo 'Booked<input type="button" style="background-color:green; border:none; width:23px; padding:2px; margin:2px;disabled=true;value="" />Available';
?>
<div>
<div style="border:1px solid red;padding:10px 5px;border-radius:5px;width:50%;">
<?php
$N = $seatnum+1;
$count=0;
for($i=1; $i < $N; $i++)
{
  if($count==4)
  $count=0;
  $res = mysqli_query($link,"SELECT * from seat where busid='$id' and seat='$i' and date='$date'");
  $currentrow = mysqli_fetch_array($res);
  $status = $currentrow['status'];  
  if($count==2)
  echo '&nbsp&nbsp&nbsp&nbsp';
  if($status=='Booked')
  echo '<input type="button" style="background-color:red; border:none; width:23px; padding:2px; margin:2px;disabled=true;" value="'.$i.'" />';
  else
  echo '<input type="button" style="background-color:green; border:none; width:23px; padding:2px; margin:2px;" value="'.$i.'" />'; 
  $count=$count+1;
}
?>
</div>
<div style="color:blue;width: 50%">
<?php
    $sresult = mysqli_query($link,"SELECT capacity,available from bus where id='$id'");
    $row1 = mysqli_fetch_array($sresult);
    $capacity = $row1['capacity']; 
    $available = $row1['available'];
    echo '<br><strong>Total seats: '.$capacity. '</strong><br>';
    echo '<br><strong>Available number of seats: '.$available. '</strong><br>';
?>
</div>
</div>
