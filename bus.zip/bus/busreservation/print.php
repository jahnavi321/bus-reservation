<script language="javascript">
function Clickheretoprint()
{ 
  var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
      disp_setting+="scrollbars=yes,width=400, height=400, left=100, top=25"; 
  var content_vlue = document.getElementById("print_content").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('<html><head><title>Ticket Reservation Information</title>'); 
   docprint.document.write('</head><body onLoad="self.print()" style="width: 400px; font-size:12px; font-family:arial;">');          
   docprint.document.write(content_vlue);          
   docprint.document.write('</body></html>'); 
   docprint.document.close(); 
   docprint.focus(); 
}
</script>
Print and present this details upon boarding the bus<br><br>
<a href="javascript:Clickheretoprint()">Print</a>
<div id="print_content" style="width: 400px;">
<strong>Ticket Reservation Details</strong><br><br>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$link = mysqli_connect('localhost', 'root', 'rushi123','ticket');

if (!$link)
{
    die('Connect Error (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
}
$id=$_GET['id'];

if(isset($_GET['rt']))
$rid=$_GET['rt'];

if(isset($_GET['reserve']))
{

$r=$_GET['reserve'];

$join1 = mysqli_query($link,"SELECT a.origin,a.destination,b.model,b.type,b.departure,b.arrival FROM route a,bus b WHERE a.id=b.routeid and b.id='$id'");
$row1 = mysqli_fetch_array($join1);

echo '<strong>Route: </strong>'.$row1['origin'].' to '.$row1['destination'].'<br>';
echo '<strong>Bus Details: </strong>'.$row1['model'].' '.$row1['type'].'<br> Departure Time :'.$row1['departure'].'<br> Arrival Time:'.$row1['arrival'].'<br>';	

$join2 = mysqli_query($link,"SELECT a.seatnum,a.payable,a.date,a.transaction,b.fname,b.lname,b.contact,b.email FROM reserve a,customer b WHERE a.customerid=b.id and a.id='$r'");
$row2 = mysqli_fetch_array($join2);

echo '<strong>Customer Name: </strong> '.$row2['fname'].' '.$row2['lname'].'<br>';
echo '<strong>Contact Details:  </strong><br>Mobile :'.$row2['contact'].'<br> Email: '.$row2['email'].'<br>';
echo '<strong>Reservation Details: </strong><br>Ticket Id: '.$row2['transaction'].' - Seat No:'.$row2['seatnum'].', Amount Paid : '.$row2['payable'].'<br> Data of Journey :'.$row2['date'].'<br>';	
echo '<strong><br> Use Ticket Id for any enquiry you may have </strong><br>'; 
}
else
{
     echo '<br><strong>Either seats are already booked or form values has errors..<br>Please update the form with proper values and try again</strong><br>';
}
?>
</div> <br>
<a href="index.php">Home</a>


