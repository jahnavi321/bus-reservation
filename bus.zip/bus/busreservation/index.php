<?php
	//Start session
	session_start();
	
	unset($_SESSION['SESS_MEMBER_ID']);
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Welcome to Online Bus Ticket Reservation</title>
<link rel="stylesheet" type="text/css" href="xres/css/style.css" />
<link rel="icon" type="image/png" href="xres/images/jb2/logo.png" />

<script type="text/javascript" src="xres/js/saslideshow.js"></script>
<script type="text/javascript" src="xres/js/slideshow.js"></script>
<script src="js/jquery-1.5.min.js" type="text/javascript" charset="utf-8"></script>
<script src="vallenato/vallenato.js" type="text/javascript" charset="utf-8"></script>
<link rel="stylesheet" href="vallenato/vallenato.css" type="text/css" media="screen" charset="utf-8">


		<script type="text/javascript">
		$("#slideshow > div:gt(0)").hide();

		setInterval(function() { 
		  $('#slideshow > div:first')
			.fadeOut(1000)
			.next()
			.fadeIn(1000)
			.end()
			.appendTo('#slideshow');
		},  3000);
	</script>
	<!--sa calendar-->	
		<script type="text/javascript" src="js/datepicker.js"></script>
        <link href="css/demo.css"       rel="stylesheet" type="text/css" />
        <link href="css/datepicker.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript">
		//<![CDATA[

		function makeTwoChars(inp) {
				return String(inp).length < 2 ? "0" + inp : inp;
		}

		function initialiseInputs() {
				
				document.getElementById("sd").value = "";
				document.getElementById("ed").value = "";
			
				datePickerController.addEvent(document.getElementById("sd"), "change", setReservationDates);
		}

		var initAttempts = 0;

		function setReservationDates(e) {
			
				try {
						var sd = datePickerController.getDatePicker("sd");
						var ed = datePickerController.getDatePicker("ed");
				} catch (err) {
						if(initAttempts++ < 10) setTimeout("setReservationDates()", 50);
						return;
				}

				// Check the value of the input is a date of the correct format
				var dt = datePickerController.dateFormat(this.value, sd.format.charAt(0) == "m");

				// If the input's value cannot be parsed as a valid date then return
				if(dt == 0) return;

			
				var edv = datePickerController.dateFormat(document.getElementById("ed").value, ed.format.charAt(0) == "m");

			
				ed.setRangeLow( dt );
			
				if(edv < dt) {
						document.getElementById("ed").value = "";
				}
		}

		function removeInputEvents() {
				// Remove the onchange event handler set within the function initialiseInputs
				datePickerController.removeEvent(document.getElementById("sd"), "change", setReservationDates);
		}

		datePickerController.addEvent(window, 'load', initialiseInputs);
		datePickerController.addEvent(window, 'unload', removeInputEvents);

        function getbuslist()
        {
             var e=document.getElementById("routeid");
             var b = e.options[e.selectedIndex].value;
              var x = document.getElementById("busid");    
                       
                 for (var i=0; i<x.length; i++)
                 {  
                    if(x.options[i].value == "Please select...")
                    {
                      var p = 1;                                     
                    }
                    else
                    {
                      if(x.options[i].selected)
                         x.remove(i);
                       x.remove(i);                   
                    }
                 }            
                
             
             $.ajax({
               async: false,
               datatype: "json",
               type: "POST",
               url: "getbus.php", 
               data: {routenum: b},
               success: function(output)
               {
                 var r = jQuery.parseJSON(output);   
                 for(var i=0;i<r.length;i++)
                 {
                   var opt = document.createElement("option");
                   document.getElementById("busid").options.add(opt);   
                   var s = r[i].model;
                   s = s+":"+r[i].type+":"+r[i].price;
                   opt.text=s;  
                   opt.value=r[i].id;  
                }   
                
               }                  
            });              
         }
		
		</script> 

</head>

<body>
<div id="wrapper">
	<div id="header">
            <ul id="mainnav">
			<li class="current"><a href="index.php">Home</a></li>          
            <li><a href="routes.php">Routes</a></li>            
            <li><a href="contact.php">Contact Us</a></li>
    	</ul>
	</div>
    <div id="content">
    	<div id="rotator">
              <ul>
                    <li class="show"><img src="xres/images/jb2/img2.jpg" width="861" height="379"  alt="" /></li>
                    <li><img src="xres/images/jb2/img3.jpg" width="861" height="379"  alt="" /></li>
                    <li><img src="xres/images/jb2/bus3.jpg" width="861" height="379"  alt="" /></li>
                    <li><img src="xres/images/jb2/bus4.jpg" width="861" height="379"  alt="" /></li>
                    <li><img src="xres/images/jb2/img4.jpg" width="861" height="379"  alt="" /></li>
                    <li><img src="xres/images/jb2/img5.jpg" width="861" height="379"  alt="" /></li>
              </ul>
			  
			  <div id="logo" style="left: 600px; height: auto; top: 23px; width: 260px; position: absolute; z-index:4;">
					
					<h2 class="accordion-header" style="height: 18px; margin-bottom: 15px; color: rgb(255, 255, 255); background: none repeat scroll 0px 0px rgb(53, 48, 48);">Ticket Booking</h2>
					<div class="accordion-content" style="margin-bottom: 15px;">
						<form action="selectset.php" method="post" style="margin-bottom:none;">
						<span style="margin-right: 11px;">Select Route:
					    <select id="routeid" name="route" style="width: 191px; margin-left: 15px; border: 3px double #CCCCCC; padding:5px 10px;" onchange="getbuslist();">;
						<?php
						error_reporting(E_ALL);
                        ini_set('display_errors', 1);
                        $link = mysqli_connect('localhost', 'root', 'rushi123','ticket');
                        if (!$link)
                        {
                            die('Connect Error (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
                        }
	
						$sql = 'SELECT * from route';
						$res = mysqli_query($link,$sql);
						if(!$res)
						{
						  echo "<p>There was an error in query: $sql</p>";
                          die("Error number: ".mysqli_errno($link)." Error description: " . mysqli_error($link));
                        }
						echo '<option value="">Please select...</option>';											
						while($row  = mysqli_fetch_array($res))
						{	
							  echo '<option value="'.$row['id'].'">';
							  echo $row['origin'].'  :'.$row['destination'].' ';
							  echo '</option>';		  					
					    }			    
					   
						?>
						</select>
						</span><br>
						<span style="margin-right: 11px;">Select Bus:
					    <select id="busid" name="bus" style="width: 191px; margin-left: 15px; border: 3px double #CCCCCC; padding:5px 10px;">;
					    <?php
					    $sql = 'SELECT * from bus';
						$res = mysqli_query($link,$sql);
						if(!$res)
						{
						  echo "<p>There was an error in query: $sql</p>";
                          die("Error number: ".mysqli_errno($link)." Error description: " . mysqli_error($link));
                        }
						echo '<option value="Please select...">Please select...</option>';																						   
						?>
					    </select>
						</span><br>
						<span style="margin-right: 11px;">Date: 
						<input type="text" class="w8em format-d-m-y highlight-days-67 range-low-today" name="date" id="sd" value="" maxlength="10" readonly="readonly" style="width: 165px; margin-left: 15px; border: 3px double #CCCCCC; padding:5px 10px;"/>
						</span><br>
						<span style="margin-right: 11px;">No. of Passenger: 
						<select name="qty" style="width: 191px; margin-left: 15px; border: 3px double #CCCCCC; padding:5px 10px;">
						<option>1</option>
						<option>2</option>
						<option>3</option>
						<option>4</option>
						<option>5</option>
						<option>6</option>
						<option>7</option>
						<option>8</option>
						<option>9</option>
						</select>
						</span><br><br>
						<input type="submit" id="submit" value="Next" style="height: 34px; margin-left: 15px; width: 191px; padding: 5px; border: 3px double rgb(204, 204, 204);" />
						</form>
					</div>
					
					 <div id="logo" style="right: 600px; height: auto; top: 5px; left: -300px;width: 260px; position: absolute; z-index:4;">					
					<h2 class="accordion-header" style="height: 20px; margin-bottom: 15px; color: rgb(255, 255, 255); background: none repeat scroll 0px 0px rgb(53, 48, 48);">Ticket Cancellation</h2>
					<div class="accordion-content" style="margin-bottom: 15px;">
						<form action="cancel.php" method="post" style="margin-bottom:none;">
					    <span style="margin-right: 11px;">Contact: <input type="text" name="contact" style="width: 165px; margin-left: 15px; border: 3px double #CCCCCC; padding:5px 10px;"/></span><br>
						<span style="margin-right: 11px;">Seat: <input type="text" name="seatnum" style="width: 165px; margin-left: 15px; border: 3px double #CCCCCC; padding:5px 10px;"/>
						</span><br>
						<span style="margin-right: 11px;">Date of Journey: 
						<input type="text" class="w8em format-d-m-y highlight-days-67 range-low-today" name="doj" id="jd" value="" maxlength="10" readonly="readonly" style="width: 165px; margin-left: 15px; border: 3px double #CCCCCC; padding:5px 0px;"/>
						</span><br>
						 <span style="margin-right: 11px;">Ticket Id: <input type="text" name="tid" style="width: 165px; margin-left: 15px; border: 3px double #CCCCCC; padding:5px 10px;"/>
						</span><br><br>
						<input type="submit" id="submit" value="Next" style="height: 34px; margin-left: 15px; width: 191px; padding: 5px; border: 3px double rgb(204, 204, 204);" />		
					    </form>
					</div>
					</div>
					
					
					
					<div id="logo" style="right: 600px; height: auto; top: 5px; width: 260px; position: absolute; z-index:4;">
					<h2 class="accordion-header" style="height: 18px; margin-bottom: 15px; color: rgb(255, 255, 255); background: none repeat scroll 0px 0px rgb(53, 48, 48);">Admin Login</h2>
					<div class="accordion-content" style="margin-bottom: 15px;">
						<form action="login.php" method="post" style="margin-bottom:none;">
						<span style="margin-right: 11px;">Username: <input type="text" name="username" style="width: 165px; margin-left: 15px; border: 3px double #CCCCCC; padding:5px 10px;"/></span><br>
						<span style="margin-right: 11px;">Password: <input type="password" name="password" style="width: 165px; margin-left: 15px; border: 3px double #CCCCCC; padding:5px 10px;"/></span><br><br>
						<input type="submit" id="submit" class="medium gray button" value="Login" style="height: 34px; margin-left: 15px; width: 191px; padding: 5px; border: 3px double rgb(204, 204, 204);" />
						</form>
					</div>
				</div>
	        </div>		
    </div>
    </div>  
	<div id="footer">
	<h4>+91 9949694059 &bull; <a href="contact-us.php"> IIITS Hostel, Sricity, Andhra Pradesh  </a></h4>
	<p>Hours of Operation&nbsp;&nbsp;&bull;&nbsp;&nbsp;Mon - Sun: 10:00 am - 06:00 pm</p>	
	</div>
</div>
</body>
</html>
