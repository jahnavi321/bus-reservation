
<br><br>
<strong>Seat Validation Details</strong><br><br>
<?php

$response=$_GET['id'];

echo '<br><strong>Seats already booked!<br>Please update the form with proper values and try again</strong><br>';

?>
</div> <br>
<a href="index.php">Home</a>

