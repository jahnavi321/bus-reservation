<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

$link = mysqli_connect('localhost', 'root', 'rushi123','ticket');

if (!$link)
{
    die('Connect Error (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
}


function createRandomPassword() {
	$chars = "abcdefghijkmnopqrstuvwxyz023456789";
	srand((double)microtime()*1000000);
	$i = 0;
	$pass = '' ;
	while ($i <= 7) {
		$num = rand() % 33;
		$tmp = substr($chars, $num, 1);
		$pass = $pass . $tmp;
		$i++;
	}
	return $pass;
}
$confirmation = createRandomPassword();

$fname=$_POST['fname'];
$qty=$_POST['qty'];
$lname=$_POST['lname'];
$busnum=$_POST['bus'];
$routenum=$_POST['route'];
$seatnum=$_POST['seatnum'];
$date=$_POST['date'];
$contact=$_POST['contact'];
$address=$_POST['address'];
$email=$_POST['mail'];



$result = mysqli_query($link,"SELECT * FROM bus WHERE id='$busnum'");
while($row = mysqli_fetch_array($result))
	{
	$price=$row['price'];
	}
	$payable=$qty*$price;

$creseult = mysqli_query($link,"INSERT IGNORE INTO customer (fname, lname, address, contact,email) VALUES ('$fname', '$lname', '$address', '$contact','$email')");

   $res = mysqli_query($link,"SELECT id from customer where contact = '$contact'");
   while($crow = mysqli_fetch_array($res))
   {
       $cid = $crow['id'];
   }
   

$vardate = str_replace('/', '-', $date);

$date = date('Y-m-d', strtotime($vardate));

$seats = explode(",",$seatnum);  
$snum = count($seats);
$affected=0;

for($i=0;$i<$snum;$i++)
{
     $uresult = mysqli_query($link,"INSERT IGNORE INTO seat(busid,date,status,seat) values('$busnum','$date','Booked','$seats[$i]')");
     if(mysqli_affected_rows($link)>0)
     {
       $affected=1;      
     }    
}

 
if($affected)
{
$results = mysqli_query($link,"INSERT INTO reserve (busid,customerid, seatnum,date,status,payable,ts,transaction,quantity) VALUES ('$busnum','$cid','$seatnum','$date','Booked','$payable',CURRENT_TIMESTAMP,'$confirmation','$qty')");

$result = mysqli_query($link,"SELECT id from reserve where customerid='$cid' and transaction='$confirmation'");

  $r = mysqli_fetch_array($result);
  $rid = $r['id'];
      
header("location: print.php?id=$busnum&reserve=$rid&rt=$routenum");  
}
else
header("location: print.php?id=$busnum&rt=$routenum");  
 
?>
