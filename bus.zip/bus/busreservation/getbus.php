<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$link = mysqli_connect('localhost', 'root', 'rushi123','ticket');

if (!$link)
{
    die('Connect Error (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
}

$rid = $_POST['routenum'];
 
$sql = "SELECT * FROM bus WHERE routeid ='$rid'";

$res = mysqli_query($link,$sql);

$results = array();

while($r = mysqli_fetch_array($res))
{
    $results[] = $r;  
}

echo json_encode($results);

?>
