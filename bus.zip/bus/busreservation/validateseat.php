<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$link = mysqli_connect('localhost', 'root', 'rushi123','ticket');

if (!$link)
{
    die('Connect Error (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
}

var_dump($_POST);

 $seat=$_POST['seatnum'];
 $bid=$_POST['busnum'];
 $date=$_POST['doj'];
 
 
$sql = "SELECT * FROM seat WHERE busid ='$bid' and seat = '$seat' and date = '$date' and status = 'Booked' ";

$res = mysqli_query($link,$sql);

$rowcount=mysqli_num_rows($res);

$response = array();

if($rowcount>0)
{
  $response['status'] = 'error';
  $response['message'] = 'Seat is already booked';
}
else
{
  $response['status'] = 'success';
  $response['message'] = 'Seat is available';
  
}

echo json_encode($response);

?>
