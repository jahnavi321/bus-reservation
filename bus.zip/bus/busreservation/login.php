<?php
	//Start session
	session_start();
	
	
		
	//Function to sanitize values received from the form. Prevents SQL injection
	function clean($str) {
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}
	
	
error_reporting(E_ALL);
ini_set('display_errors', 1);

$link = mysqli_connect('localhost', 'root', 'rushi123','ticket');

if (!$link)
{
    die('Connect Error (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
}
	
	//Sanitize the POST values
	$login = $_POST['username'];
	$password = $_POST['password'];
	
	//Create query
	$qry="SELECT * FROM users WHERE username='admin' AND password='admin'";
	$result=mysqli_query($link,$qry);
	
	if($result) 
	{
		if(mysqli_num_rows($result) > 0) {
			//Login Successful		
			echo "<script>alert('login successful!');</script>";			
			header("location: routes.php");			
		}
		else
		{
			echo "<html><script>alert('login failed!');</script><body></body></html>";				
		}
	}else {
		die("Query failed");
	}
?>


