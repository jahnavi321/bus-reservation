<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
   <script src="js/jquery-1.5.min.js" type="text/javascript"></script>
  <script src="src/facebox.js" type="text/javascript"></script>
  <script type="text/javascript">
    jQuery(document).ready(function($) {
      $('a[rel*=facebox]').facebox({
        loadingImage : 'src/loading.gif',
        closeImage   : 'src/closelabel.png'
      })
    })
  </script>
<style>
body{
font-family:"Lucida Grande", "Lucida Sans Unicode", Verdana, Arial, Helvetica, sans-serif;
font-size:12px;
}
p, h1, form, button{border:0; margin:0; padding:0;}
.spacer{clear:both; height:1px;}
/* ----------- My Form ----------- */
.myform{
margin:0 auto;
width:400px;
padding:14px;
}

/* ----------- stylized ----------- */
#stylized{
border:solid 2px #b7ddf2;
background:#ebf4fb;
}
#stylized h1 {
font-size:14px;
font-weight:bold;
margin-bottom:8px;
}
#stylized p{
font-size:11px;
color:#666666;
margin-bottom:20px;
border-bottom:solid 1px #b7ddf2;
padding-bottom:10px;
}
#stylized label{
display:block;
font-weight:bold;
text-align:right;
width:140px;
float:left;
}
#stylized .small{
color:#666666;
display:block;
font-size:11px;
font-weight:normal;
text-align:right;
width:140px;
}
#stylized input{
float:left;
font-size:12px;
padding:4px 2px;
border:solid 1px #aacfe4;
width:200px;
margin:2px 0 20px 10px;
}
#stylized button{
clear:both;
margin-left:150px;
width:125px;
height:31px;
background:#666666 url(img/button.png) no-repeat;
text-align:center;
line-height:31px;
color:#FFFFFF;
font-size:11px;
font-weight:bold;
}
</style>
<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

$link = mysqli_connect('localhost', 'root', 'rushi123','ticket');

if (!$link)
{
    die('Connect Error (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
}

$routeid=$_POST['route'];
$busid=$_POST['bus'];
$date=$_POST['date'];
$qty=$_POST['qty'];

$olddate = $date;

$vardate = str_replace('/', '-', $olddate);

$newdate = date('Y-m-d', strtotime($vardate));

$sql = "SELECT * FROM bus WHERE id ='$busid' and routeid = '$routeid' ";

$res = mysqli_query($link,$sql);

$row = mysqli_fetch_array($res);

$numofseats=$row['capacity'];
$numavailable=$row['available'];
$avail = $numavailable;    

?>
<?php
if ($avail < $qty)
{
echo 'Qty reserve exced the available seat of the bus';
}
else if($avail > 0)
{
?>
<script type="text/javascript">



function validateseat()
{
   var seat=document.forms["form"]["seatnum"].value;
   var a=seat.split(",");
   var q = <?php echo $qty ?>;
   var b = <?php echo $busid ?>;
   var dt = "<?php echo $newdate ?>";
   if(a.length>q)
   {
   alert("Enter only "+q+" seat");   
   return false;
   }
   var response="";
   var flag=true;
   for(var i=0;i<a.length;i++)
   {
        $.ajax({
        async: false,
        datatype: "json",
        type: "POST",
        url: "validateseat.php", 
        data: {seatnum: a[i],busnum: b,doj: dt},
        error: function(output)
        {  
            var res = jQuery.parseJSON(output);
            if(res.status == 'error')
            {
                response = response + " " + a[i];  
                alert(response); 
                return false;
            }                                    
        }                      
      });           
   } 
   if(response!="")
   {
     alert("Seat already booked");
     return false;
   }
}

function hasWhiteSpace(s) 
{
  return /\s/g.test(s);
}

function validateForm()
{

 var s=document.forms["form"]["seatnum"].value;
 if(s==null || s=="")
 {
  alert("Seat numbers must be filled out");
  return false;
 }
 else
 { 
  var sp = hasWhiteSpace(s);
  if(sp == true)
  {
     alert("Please use comman separated list of numbers!");
     return false;
  }  
  else
  {
   var a=s.split(",");
   var q = <?php echo $qty ?>;
   if(a.length!=q)
   {
   alert("Enter  "+q+" seats");   
   return false;
   }
   }  
  }
var x=document.forms["form"]["fname"].value;
if (x==null || x=="")
  {
  alert("First Name must be filled out");
  return false;
  }
var y=document.forms["form"]["lname"].value;
if (y==null || y=="")
  {
  alert("Last Name must be filled out");
  return false;
  }
var a=document.forms["form"]["address"].value;
if (a==null || a=="")
  {
  alert("Address must be filled out");
  return false;
  }
var e=document.forms["form"]["mail"].value;
if (e==null || e=="")
  {
  alert("email must be filled out");
  return false;
  }
var b=document.forms["form"]["contact"].value;
if (b==null || b=="")
  {
  alert("Contact Number must be filled out");
  return false;
  }
  var val = b;
  if (/^\d{10}$/.test(val))
   {
    // value is ok, use it
    return true;
   } else {
    alert("Invalid number; enter ten digit mobile number");
    return false;
   }
}

</script>
<div id="stylized" class="myform">

<form id="form" name="form" action="save.php" method="post"  onsubmit="return validateForm(this);">
<input type="hidden" value="<?php echo $routeid ?>" name="route" />
<input type="hidden" value="<?php echo $busid ?>" name="bus" />
<input type="hidden" value="<?php echo $date ?>" name="date" />
<input type="hidden" value="<?php echo $qty ?>" name="qty" />
<label>Seat Number
<span class="small">Enter seat details</span>
<span class="small"> <a rel="facebox" href="seatlocation.php?id=<?php echo $busid; ?>&doj=<?php echo $date; ?>">view seat</a></span>
</label>
<input type="text" name="seatnum" id="name"><br>
<label>First Name
<span class="small">Enter first name</span>
</label>
<input type="text" name="fname"  id="name"/><br>
<label>Last Name
<span class="small">Enter last name</span>
</label>
<input type="text" name="lname"  id="name"/><br>
<label>Address
<span class="small">Enter Address</span>
</label>
<input type="text" name="address"  id="name"/><br>
<label>email
<span class="small">Enter email id</span>
</label>
<input type="text" name="mail"  id="name"/><br>
<label>Contact
<span class="small">Enter Contact Number</span>
</label>
<input type="text" name="contact"  id="name"/><br>
<button type="submit">Confirm</button>
</form>
</div>
<?php
}
else if($avail <= 0)
{
echo 'no available sets';
}
?>
