<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

$link = mysqli_connect('localhost', 'root', 'rushi123','ticket');

if (!$link)
{
    die('Connect Error (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
}


$contact=$_POST['contact'];
$date=$_POST['doj'];
$seatnum=$_POST['seatnum'];
$confirmation=$_POST['tid'];

$olddate = $date;

$vardate = str_replace('/', '-', $olddate);

$newdate = date('Y-m-d', strtotime($vardate));

$seats = explode(",",$seatnum);  
$snum = count($seats);
$affected=0;

  $sresult = mysqli_query($link,"SELECT * from reserve where transaction = '$confirmation' and status = 'Booked' and date = '$newdate' and seatnum = '$seatnum' and customerid in (select id from customer where contact = '$contact' )");
     if(mysqli_affected_rows($link)>0)
     {
       $affected=1;       
     }    
     
    if($affected==1)
    {
     $uresult = mysqli_query($link,"update reserve set status = 'Cancelled' where transaction = '$confirmation' and date = '$newdate' and seatnum = '$seatnum'");
     if(mysqli_affected_rows($link)>0)
     {
       $affected=1;       
     }  
     else
     $affected=0;   
    }

if($affected==0)
{
  header("location:cancelresult.php?id=$seatnum");  
}
else
{
  for($i=0;$i<$snum;$i++)
  {
  $results = mysqli_query($link,"delete r from reserve s left join seat r on s.busid=r.busid and s.date=r.date and s.transaction = '$confirmation' and r.seat='$seats[$i]' and r.status='Booked'");
  }
  header("location: confirmcancel.php?id=$seatnum");  
}

?>
