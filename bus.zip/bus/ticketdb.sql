

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `ticket`
--
create database ticket;

use ticket;
--
-- Table structure for table `route`
--

CREATE TABLE IF NOT EXISTS `route` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `origin` varchar(100) NOT NULL,
  `destination` varchar(100) NOT NULL, 
  PRIMARY KEY (`id`)
);


CREATE TABLE  IF NOT EXISTS `bus` (	
	`id` int(10) NOT NULL AUTO_INCREMENT,
	`routeid` int(10) NOT NULL,
	`model` VARCHAR(40) NOT NULL, 
	`type` VARCHAR(30) NOT NULL,
	`capacity` int(10) NOT NULL,
	`available` int(10) NOT NULL,
	`price` FLOAT(10,2) NOT NULL, 
	`date` VARCHAR(100) NOT NULL,
	`departure` VARCHAR(50)  NOT NULL, 
	`arrival` VARCHAR(50) NOT NULL, 
	 PRIMARY KEY (`id`), 
     FOREIGN KEY (`routeid`) REFERENCES `route` (`id`));


--
-- Table structure for table `seat`
--

CREATE TABLE IF NOT EXISTS `seat` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `busid` int(10) NOT NULL, 
  `date` varchar(100) NOT NULL,
  `status` varchar(15) NOT NULL,
  `seat` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`busid`) REFERENCES `bus`(`id`),
  CONSTRAINT useat UNIQUE (busid,date,status,seat)  
);


--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `address` varchar(300) NOT NULL,
  `email` varchar(100) NOT NULL, 
  PRIMARY KEY (`id`),
  CONSTRAINT UC UNIQUE (contact)  
);


CREATE TABLE IF NOT EXISTS `reserve` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `busid` int(10) NOT NULL,
  `customerid` int(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `seatnum` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `status` varchar(15) NOT NULL,
  `payable` float(10,2) NOT NULL,
  `ts` timestamp null,
  `transaction` varchar(100) not null,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`busid`) REFERENCES `bus`(`id`),
  FOREIGN KEY (`customerid`) REFERENCES `customer`(`id`));
  
--

-- insert after trigger to add seat records on bus record insert ----------------

--

delimiter //
create trigger seat_info_ins after insert on bus
for each row 
begin
 declare x int ;
 declare y int;
 if(new.capacity >  0 ) then
   set x = 0 ;
   while x < new.capacity do
     set y=x+1;
     insert into seat (`busid`,`date`,`status`,`seat`)
     values
     (new.id,current_date-1,'AVAILABLE',y);
     set x=x+1;
    end while ;
  end if ;
end;//

delimiter ;

--
-- Ttigger to delete seat data on deletion of bus record (delete before) -----------------
--


DELIMITER $$
CREATE TRIGGER `before_delete`
BEFORE DELETE ON `bus`
FOR EACH ROW
BEGIN
  DELETE FROM seat WHERE seat.busid = OLD.id ;
END $$
DELIMITER ;


--
-- update trigger to modify available seats after reservation ------------------
..


delimiter $$
create trigger `seat_after_reserve` after insert on reserve
for each row
begin
   declare qty int;
   declare bid int;
   if(strcmp(new.status,"Booked")=0) then
      set qty=new.quantity;
      set bid=new.busid;
      update bus b set b.available=b.available-qty where b.id=bid;
   end if;
end  $$
delimiter ;   


--
-- update trigger to modify available seats after cancellation ------------------
..


delimiter $$
create trigger `bus_after_seatdelete` before delete on seat
for each row
begin
   declare bid int;
   if(strcmp(old.status,"Booked")=0) then
      set bid=old.busid;
      update bus b set b.available=b.available+1 where b.id=bid ;
   end if;
end  $$
delimiter ;   


--
-- Dumping data for table `route` --------------
--

INSERT INTO `route` (`id`, `origin`,`destination`) VALUES (1,'Sricity', 'Vijayawada'),(2,'Sricity', 'Hyderabad'),(3, 'Sricity', 'Visakhapatnam');

-----Insert data into Bus --------------


INSERT INTO `bus` (`id`, `routeid`,`model`,`type`,`capacity`,`available`,`price`,`date`,`departure`,`arrival`) VALUES (1,1,'Volvo','AC',40,40,400.00,CURRENT_DATE,'10.30PM','4.15AM'),(2,1,'Super Delux','Non AC',40,40,300.00,CURRENT_DATE,'11.00PM','5.00AM'),(3,2,'Volvo','AC',32,32,600,CURRENT_DATE,'8.30PM','6AM'),(4,3,'Premiere','AC',36,36,900,CURRENT_DATE,'8.00PM','6.00AM'),(5,2,'Isuze','Non AC',28,28,500,CURRENT_DATE,'9.00AM','6.30PM'),(6,3,'Volvo','AC',32,32,800,CURRENT_DATE,'10.00AM','7.00PM');



--
-- Table structure for table `admin` ------------
--




CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `access_level` int NOT NULL,
   PRIMARY KEY (`id`)
);

--
-- Dumping data for table `admin` --------------
--

INSERT INTO `users` (`id`, `username`, `password`,`access_level`) VALUES(1, 'admin', 'admin',1);


